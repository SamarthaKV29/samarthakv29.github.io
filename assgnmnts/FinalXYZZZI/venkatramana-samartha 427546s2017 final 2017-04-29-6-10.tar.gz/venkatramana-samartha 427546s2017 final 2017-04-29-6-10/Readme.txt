I have explained in detail all the libraries used and also the way I have solved the questions. 
For a live version, please visit: http://www.cs.uml.edu/~svenkatr/assgnmnts/Final/

